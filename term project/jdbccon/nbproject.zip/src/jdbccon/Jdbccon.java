/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbccon;
import javax.sql.*;
import java.sql.*;
/**
 *
 * @author SHESHANT
 */
public class Jdbccon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Connection conn = null;
        String url = "jdbc:mysql://10.5.18.67:3306/";
        String dbName = "12CS10046";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "12CS10046";
        String password = "btech12";
        try {
          Class.forName(driver).newInstance();
          conn = DriverManager.getConnection(url+dbName,userName,password);
          System.out.println("Connected to the database");
          conn.close();
          System.out.println("Disconnected from database");
        } catch (Exception e) {
            System.out.println("NO CONNECTION =(");
            e.printStackTrace();
        }
        // TODO code application logic here
    }
    
}
